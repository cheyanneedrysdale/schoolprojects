using System.ComponentModel.DataAnnotations;

namespace Assignment1.Models
{
    public class Purchase
    {
        
        // primary key 
        public int PurchaseId { get; set; }
        

        [Required]
        [Display(Name = "Purchase Date")]
        public DateTime PurchaseDate { get; set; } = DateTime.UtcNow;
        

        [Required]
        [Display(Name = "Guest Name")]
        public string GuestName { get; set; } = string.Empty;
        

        [Required]
        [EmailAddress]
        [Display(Name = "Guest Email")]
        public string GuestEmail { get; set; } = string.Empty;
        

        [Display(Name = "Total Cost")]
        public decimal TotalCost { get; set; }
        

        // one purchase can contain many items (events, quantity) //
        public List<PurchaseItem> Items { get; set; } = new();
        
        
    }
}