using System.ComponentModel.DataAnnotations;

namespace Assignment1.Models
{
    public class PurchaseItem
    
    {
        
        // foreign key: Purchase
        public int PurchaseId { get; set; }
        
        public Purchase? Purchase { get; set; }

        
        // foreign key: Event
        public int EventId { get; set; }
        
        public Event? EventInfo { get; set; }
        
        

        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }
        

        // price (at time of purchase)
        public decimal UnitPrice { get; set; }
    }
}